package fis.training.minitest_with_datajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinitestWithDatajpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MinitestWithDatajpaApplication.class, args);
    }

}
