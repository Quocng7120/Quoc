package fis.training.minitest_with_datajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinitestWithDatajpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
